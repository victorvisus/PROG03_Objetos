package ejercicio02;

/**
 *
 * @author Victor
 */
public class PruebaEjercio02 {

    public static void main(String[] args) {
        Persona03 objetoPersona;
        objetoPersona = new Persona03();
        objetoPersona.main();
    }

}
