package ejercicio03;

/**
 *
 * @author Victor
 */
public class PruebaEjercio03 {

    public static void main(String[] args) {
        Persona03 objetoPersona = new Persona03();

        System.out.println("Nombre: " + objetoPersona.nombre + " Edad: " + objetoPersona.edad + " Altura: " + objetoPersona.altura);

        //objetoPersona.main();
    }

}
