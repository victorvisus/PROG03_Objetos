package ejercicio04;

/**
 *
 * @author Victor
 */
public class PruebaEjercio04 {

    public static void main(String[] args) {
        Persona04 objetoPersona = new Persona04("Víctor", 42, 1.78f);

        System.out.println("Nombre: " + objetoPersona.nombre + "; Edad: " + objetoPersona.edad + "; Altura: " + objetoPersona.altura);

        //objetoPersona.main();
    }

}
